﻿import { Injectable, NotFoundException } from '@nestjs/common';
import * as crypto from 'crypto';
import { PrismaService } from '../prisma/prisma.service';
import { AppException } from '../common/app.exception';
import { AddToCartDto } from './dto/add-to-cart.dto';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { WalletGatewayService } from '../wallet-gateway/wallet-gateway.service';
import { RedisService } from '../common/redis/redis.service';
import { JwtService } from '@nestjs/jwt';
@Injectable()
export class OrderService {
   constructor(
     private readonly prisma: PrismaService,
     private readonly eventEmitter: EventEmitter2,
     private readonly walletGateway: WalletGatewayService,
     private readonly redis: RedisService,
      private readonly jwt: JwtService,
   ) {}

   async getEnseignes() {
     return this.prisma.enseigne.findMany({
       where: { actif: true },
       select: { id: true, nom: true, rushMode: true },
     });
   }

   async getMenu(enseigneId: string) {
     const enseigne = await this.prisma.enseigne.findUnique({ where: { id: enseigneId } });
     if (!enseigne) throw new NotFoundException('Enseigne introuvable');

     const items = await this.prisma.menuItem.findMany({
       where: { enseigneId, disponible: true },
       orderBy: { categorie: 'asc' },
     });

     const categories = items.reduce<Record<string, typeof items>>((acc, item) => {
       (acc[item.categorie] ??= []).push(item);
       return acc;
     }, {});

     return {
       enseigne: { id: enseigne.id, nom: enseigne.nom, rushMode: enseigne.rushMode },
       categories,
     };
   }

   async searchMenu(enseigneId: string, query?: string) {
     if (!query) return [];
     return this.prisma.menuItem.findMany({
       where: { enseigneId, disponible: true, nom: { contains: query, mode: 'insensitive' } },
     });
   }

   // ---------- UC4 — Gérer le panier (Order avec statut PANIER) ----------

   private async findActiveCart(userId: string) {
     return this.prisma.order.findFirst({
       where: { userId, statut: 'PANIER' },
       include: { items: { include: { menuItem: true } } },
     });
   }

   private formatCart(order: any | null) {
     if (!order) return { enseigneId: null, items: [], total: 0 };
     const items = order.items.map((i: any) => ({
       menuItemId: i.menuItemId,
       nom: i.menuItem.nom,
       quantite: i.quantite,
       prixUnitaire: Number(i.prixUnitaire),
     }));
     const total = items.reduce((sum: number, i: any) => sum + i.prixUnitaire * i.quantite, 0);
     return { enseigneId: order.enseigneId, items, total };
   }

   private async recalculateTotal(orderId: string) {
     const items = await this.prisma.orderItem.findMany({ where: { orderId } });
     const total = items.reduce((sum, i) => sum + Number(i.prixUnitaire) * i.quantite, 0);
     await this.prisma.order.update({ where: { id: orderId }, data: { totalPrix: total } });
   }

   async getCart(userId: string) {
     const cart = await this.findActiveCart(userId);
     return this.formatCart(cart);
   }

   async addToCart(userId: string, dto: AddToCartDto) {
     const menuItem = await this.prisma.menuItem.findUnique({ where: { id: dto.menuItemId } });
     if (!menuItem || !menuItem.disponible) {
       throw new AppException('MENU_ITEM_UNAVAILABLE', 'Cet article est indisponible', 409);
     }

     let cart = await this.findActiveCart(userId);

     if (cart && cart.enseigneId !== menuItem.enseigneId) {
       throw new AppException(
         'CART_SINGLE_ENSEIGNE_ONLY',
         "Le panier ne peut contenir des articles que d'une seule enseigne à la fois",
         409,
       );
     }

     if (!cart) {
       cart = await this.prisma.order.create({
         data: {
           userId,
           enseigneId: menuItem.enseigneId,
           statut: 'PANIER',
           totalPrix: menuItem.prix,
           items: {
             create: [{ menuItemId: menuItem.id, quantite: dto.quantite, prixUnitaire: menuItem.prix }],
           },
         },
         include: { items: { include: { menuItem: true } } },
       });
       await this.recalculateTotal(cart.id);
       cart = await this.findActiveCart(userId);
     } else {
       const existing = cart.items.find((i: any) => i.menuItemId === dto.menuItemId);
       if (existing) {
         await this.prisma.orderItem.update({
           where: { id: existing.id },
           data: { quantite: existing.quantite + dto.quantite },
         });
       } else {
         await this.prisma.orderItem.create({
           data: { orderId: cart.id, menuItemId: menuItem.id, quantite: dto.quantite, prixUnitaire: menuItem.prix },
         });
       }
       await this.recalculateTotal(cart.id);
       cart = await this.findActiveCart(userId);
     }

     this.eventEmitter.emit('cart.item_added', {
       userId,
       entityId: dto.menuItemId,
       metadata: { quantite: dto.quantite, enseigneId: menuItem.enseigneId },
     });
     return this.formatCart(cart);
   }

   async updateCartItem(userId: string, menuItemId: string, quantite: number) {
     const cart = await this.findActiveCart(userId);
     if (!cart) throw new AppException('CART_ITEM_NOT_FOUND', 'Article absent du panier', 404);

     const item = cart.items.find((i: any) => i.menuItemId === menuItemId);
     if (!item) throw new AppException('CART_ITEM_NOT_FOUND', 'Article absent du panier', 404);

     if (quantite === 0) {
       await this.prisma.orderItem.delete({ where: { id: item.id } });
       this.eventEmitter.emit('cart.item_removed', { userId, entityId: menuItemId });
     } else {
       await this.prisma.orderItem.update({ where: { id: item.id }, data: { quantite } });
       this.eventEmitter.emit('cart.item_updated', { userId, entityId: menuItemId, metadata: { quantite } });
     }

     const remaining = await this.prisma.orderItem.count({ where: { orderId: cart.id } });
     if (remaining === 0) {
       await this.prisma.order.delete({ where: { id: cart.id } });
       return { enseigneId: null, items: [], total: 0 };
     }

     await this.recalculateTotal(cart.id);
     return this.formatCart(await this.findActiveCart(userId));
   }

   async removeCartItem(userId: string, menuItemId: string) {
     return this.updateCartItem(userId, menuItemId, 0);
   }

   async clearCart(userId: string) {
     const cart = await this.prisma.order.findFirst({ where: { userId, statut: 'PANIER' } });
     if (cart) {
       await this.prisma.order.delete({ where: { id: cart.id } });
       this.eventEmitter.emit('cart.cleared', { userId, entityId: cart.id });
     }
     return { enseigneId: null, items: [], total: 0 };
   }

   // ---------- UC5 — Passer commande (checkout) ----------

   async checkout(userId: string) {
     const cart = await this.findActiveCart(userId);
     if (!cart || cart.items.length === 0) {
       throw new AppException('CART_EMPTY', 'Le panier est vide', 400);
     }

     const user = await this.prisma.user.findUnique({ where: { id: userId } });
     if (!user) {
       throw new AppException('USER_NOT_FOUND', 'Utilisateur introuvable', 404);
     }

     let walletReferenceId = user.walletReferenceId;
     if (!walletReferenceId) {
       walletReferenceId = crypto.randomUUID();
       await this.prisma.user.update({
         where: { id: userId },
         data: { walletReferenceId },
       });
     }

     const total = Number(cart.totalPrix);

     const balance = await this.walletGateway.getBalance(walletReferenceId, userId);
if (balance < total) {
  throw new AppException('INSUFFICIENT_BALANCE', 'Solde insuffisant', 402);
}



     const { transactionId } = await this.walletGateway.debit(walletReferenceId, total, cart.id, userId);
     const confirmedOrder = await this.prisma.order.update({
       where: { id: cart.id },
       data: {
         statut: 'RECUE',
         walletTransactionId: transactionId,
       },
     });

     this.eventEmitter.emit('order.placed', {
       userId,
       entityId: confirmedOrder.id,
       metadata: {
         enseigneId: confirmedOrder.enseigneId,
         totalDt: total,
         heureCommande: new Date().toISOString(),
       },
     });

     return {
       orderId: confirmedOrder.id,
       statut: confirmedOrder.statut,
       total,
     };
   }




// ---------- UC6 — Suivi de commande en temps réel ----------

private readonly VALID_TRANSITIONS: Record<string, string[]> = {
  RECUE: ['EN_PREPARATION', 'ANNULEE'],
  EN_PREPARATION: ['PRETE', 'ANNULEE'],
  PRETE: ['CLOTUREE'],
  CLOTUREE: [],
  ANNULEE: [],
};

async updateOrderStatus(orderId: string, nouveauStatut: string) {
  const order = await this.prisma.order.findUnique({ where: { id: orderId } });
  if (!order) throw new AppException('ORDER_NOT_FOUND', 'Commande introuvable', 404);

  const allowed = this.VALID_TRANSITIONS[order.statut] ?? [];
  if (!allowed.includes(nouveauStatut)) {
    throw new AppException(
      'INVALID_STATUS_TRANSITION',
      `Transition ${order.statut} -> ${nouveauStatut} non autorisée`,
      409,
    );
  }

  const data: any = { statut: nouveauStatut };

  // Génère le QR de récupération au moment où la commande devient PRETE (CDC §3.3)
  if (nouveauStatut === 'PRETE') {
  data.qrToken = await this.jwt.signAsync(
    { type: 'order_pickup', orderId },
    { expiresIn: '2h' },
  );
}

  const updated = await this.prisma.order.update({ where: { id: orderId }, data });

  // Publie sur Redis Pub/Sub — le TrackingGateway relaie aux clients WebSocket connectés
  await this.redis.publish(
    `order:${orderId}:status`,
    JSON.stringify({
      orderId,
      status: updated.statut, 
      qrToken: updated.qrToken ?? null,
    }),
  );

  return { orderId, statut: updated.statut };
}

async getOrderStatus(userId: string, orderId: string) {
  const order = await this.prisma.order.findFirst({ where: { id: orderId, userId } });
  if (!order) throw new AppException('ORDER_NOT_FOUND', 'Commande introuvable', 404);

  return {
    orderId: order.id,
    statut: order.statut,
    qrToken: order.qrToken,
    updatedAt: order.updatedAt,
  };
}
async getOrderQr(userId: string, orderId: string) {
  const order = await this.prisma.order.findFirst({ where: { id: orderId, userId } });
  if (!order) throw new AppException('ORDER_NOT_FOUND', 'Commande introuvable', 404);

  if (order.statut !== 'PRETE' || !order.qrToken) {
    throw new AppException(
      'QR_NOT_AVAILABLE',
      "Le QR de récupération n'est disponible que lorsque la commande est prête",
      409,
    );
  }

  // Décode l'expiration réelle du JWT plutôt que de la recalculer, pour rester
  // toujours exact même si la durée de vie du token venait à changer un jour.
  const decoded = this.jwt.decode(order.qrToken) as { exp?: number } | null;
  const expiresAt = decoded?.exp ? new Date(decoded.exp * 1000).toISOString() : null;

  return { orderId: order.id, qrToken: order.qrToken, expiresAt };
}

// ---------- UC6 (suite) — Validation du QR à la caisse ----------

async collectOrder(orderId: string, qrToken: string) {
  let payload: any;
  try {
    payload = await this.jwt.verifyAsync(qrToken);
  } catch {
    throw new AppException('INVALID_QR_TOKEN', 'QR invalide ou expiré', 401);
  }

  if (payload.type !== 'order_pickup' || payload.orderId !== orderId) {
    throw new AppException('INVALID_QR_TOKEN', 'QR invalide pour cette commande', 401);
  }

  const order = await this.prisma.order.findUnique({ where: { id: orderId } });
  if (!order) throw new AppException('ORDER_NOT_FOUND', 'Commande introuvable', 404);

  if (order.statut !== 'PRETE') {
    throw new AppException(
      'INVALID_STATUS_TRANSITION',
      `Impossible de récupérer une commande au statut ${order.statut}`,
      409,
    );
  }

  // Vérifie que le token fourni correspond bien à celui stocké — empêche la réutilisation
  // d'un ancien QR encore valide en durée mais déjà remplacé (ex: commande rouverte).
  if (order.qrToken !== qrToken) {
    throw new AppException('INVALID_QR_TOKEN', 'QR déjà utilisé ou remplacé', 401);
  }

  const updated = await this.prisma.order.update({
    where: { id: orderId },
    data: {
      statut: 'CLOTUREE',
      qrScannedAt: new Date(),
      qrToken: null, // usage unique — invalide immédiatement après scan
    },
  });

  await this.redis.publish(
    `order:${orderId}:status`,
    JSON.stringify({ orderId, status: updated.statut, qrToken: null }),
  );

  return { orderId, statut: updated.statut, qrScannedAt: updated.qrScannedAt };
}


}
