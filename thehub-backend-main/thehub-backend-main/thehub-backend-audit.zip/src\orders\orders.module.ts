import { Module } from '@nestjs/common';
import { OrderController } from './orders.controller';
import { OrderService } from './orders.service';
import { AuthModule } from '../auth/auth.module';
import { WalletGatewayModule } from '../wallet-gateway/wallet-gateway.module';
import { TrackingGateway } from './tracking.gateway';
@Module({
  imports: [AuthModule,WalletGatewayModule],
  controllers: [OrderController],
  providers: [OrderService, TrackingGateway],  // <-- JwtAuthGuard ajouté ici
})
export class OrderModule {}